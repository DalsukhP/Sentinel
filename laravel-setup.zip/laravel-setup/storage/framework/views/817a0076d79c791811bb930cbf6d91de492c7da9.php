<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Login</h3>
            </div>
            <div class="panel-body">
                <form accept-charset="UTF-8" role="form" method="post" action="<?php echo e(route('auth.login.attempt')); ?>">
                <fieldset>
                    <div class="form-group <?php echo e(($errors->has('email')) ? 'has-error' : ''); ?>">
                        <input class="form-control" placeholder="E-mail" name="email" type="text" value="<?php echo e(old('email')); ?>">
                        <?php echo ($errors->has('email') ? $errors->first('email', '<p class="text-danger">:message</p>') : ''); ?>

                    </div>
                    <div class="form-group  <?php echo e(($errors->has('password')) ? 'has-error' : ''); ?>">
                        <input class="form-control" placeholder="Password" name="password" type="password" value="">
                        <?php echo ($errors->has('password') ? $errors->first('password', '<p class="text-danger">:message</p>') : ''); ?>

                    </div>
                    <div class="checkbox">
                        <label>
                            <input name="remember" type="checkbox" value="true" <?php echo e(old('remember') == 'true' ? 'checked' : ''); ?>> Remember Me
                        </label>
                    </div>
                    <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                    <input class="btn btn-lg btn-primary btn-block" type="submit" value="Login">
                    <p style="margin-top:5px; margin-bottom:0"><a href="<?php echo e(route('auth.password.request.form')); ?>" type="submit">Forgot your password?</a></p>
                </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Centaur::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalsukh/dalsukh/code/sentinel/resources/views/centaur/auth/login.blade.php ENDPATH**/ ?>
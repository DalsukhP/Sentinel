<?php

    $vars = Session::all();
    foreach ($vars as $key => $value) {
        switch($key) {
            case 'success':
            case 'error':
            case 'warning':
            case 'info':
                ?>
                <div class="row">
                    <div class="alert alert-<?php echo e(($key == 'error') ? 'danger' : $key); ?> alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong><?php echo e(ucfirst($key)); ?>:</strong> <?php echo $value; ?>

                    </div>
                </div>
                <?php
                Session::forget($key);
                break;
            default:
        }
    }

?>
<?php /**PATH /home/dalsukh/dalsukh/code/sentinel/resources/views/centaur/notifications.blade.php ENDPATH**/ ?>
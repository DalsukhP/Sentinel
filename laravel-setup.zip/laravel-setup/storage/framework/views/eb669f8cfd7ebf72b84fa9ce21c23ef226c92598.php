<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Register</h3>
            </div>
            <div class="panel-body">
                <form accept-charset="UTF-8" role="form" method="post" action="<?php echo e(route('auth.register.attempt')); ?>">
                <fieldset>
                    <div class="form-group <?php echo e(($errors->has('email')) ? 'has-error' : ''); ?>">
                        <input class="form-control" placeholder="E-mail" name="email" type="text" value="<?php echo e(old('email')); ?>">
                        <?php echo ($errors->has('email') ? $errors->first('email', '<p class="text-danger">:message</p>') : ''); ?>

                    </div>
                    <div class="form-group  <?php echo e(($errors->has('password')) ? 'has-error' : ''); ?>">
                        <input class="form-control" placeholder="Password" name="password" type="password">
                        <?php echo ($errors->has('password') ? $errors->first('password', '<p class="text-danger">:message</p>') : ''); ?>

                    </div>
                    <div class="form-group  <?php echo e(($errors->has('password_confirmation')) ? 'has-error' : ''); ?>">
                        <input class="form-control" placeholder="Confirm Password" name="password_confirmation" type="password">
                        <?php echo ($errors->has('password_confirmation') ? $errors->first('password_confirmation', '<p class="text-danger">:message</p>') : ''); ?>

                    </div>
                    <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                    <input class="btn btn-lg btn-primary btn-block" type="submit" value="Sign Me Up!">
                </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Centaur::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalsukh/dalsukh/code/sentinel/resources/views/centaur/auth/register.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Welcome</h2>

		<p><b>Account:</b> <?php echo e($email); ?></p>
		<p>To activate your account, <a href="<?php echo e(route('auth.activation.attempt', urlencode($code))); ?>">click here.</a></p>
		<p>Or point your browser to this address: <br /> <?php echo route('auth.activation.attempt', urlencode($code)); ?> </p>
		<p>Thank you!</p>
	</body>
</html><?php /**PATH /home/dalsukh/dalsukh/code/sentinel/resources/views/centaur/email/welcome.blade.php ENDPATH**/ ?>
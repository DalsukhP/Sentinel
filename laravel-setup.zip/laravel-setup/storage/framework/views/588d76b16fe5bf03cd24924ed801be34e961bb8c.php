<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if(Sentinel::check()): ?>
    <div class="jumbotron">
        <h1>Hello, <?php echo e(Sentinel::getUser()->email); ?>!</h1>
        <p>You are now logged in.</p>
    </div>
    <?php else: ?>
        <div class="jumbotron">
            <h1>Welcome, Guest!</h1>
            <p>You must login to continue.</p>
            <p><a class="btn btn-primary btn-lg" href="<?php echo e(route('auth.login.form')); ?>" role="button">Log In</a></p>
        </div>
    <?php endif; ?>

    <?php
        $user = Sentinel::findById(1);

        // var_dump(Activation::create($user));
    ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Centaur::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalsukh/dalsukh/code/sentinel/resources/views/centaur/dashboard.blade.php ENDPATH**/ ?>
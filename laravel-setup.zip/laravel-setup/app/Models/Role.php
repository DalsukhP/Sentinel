<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Cartalyst\Sentinel\Roles\EloquentRole;
use Carbon\Carbon;
use DB;

// use HipsterJazzbo\Landlord\BelongsToTenant;

class Role extends EloquentRole
{

    // use BelongsToTenant;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'roles';
    protected $fillable = ['slug', 'name', 'permissions'];
    protected $dependency = array(
        'Role User' => array('field' => 'user_id', 'model' => RoleUser::class),
    );

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
    ];

    public function roleuser() {
        return $this->hasOne(RoleUser::class, 'role_id')->count();
        //return $this->hasMany(RoleUser::class)->whereRoleId($this->role_id)->count();
    }

}

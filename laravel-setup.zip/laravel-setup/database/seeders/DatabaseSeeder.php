<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $adminRole = Role::create(['name' => 'admin']);
        $authorRole = Role::create(['name' => 'author']);
        $viewerRole = Role::create(['name' => 'viewer']);
        Permission::create(['name' => 'create post']);
        Permission::create(['name' => 'edit post']);
        Permission::create(['name' => 'delete post']);
        Permission::create(['name' => 'view post']);
        $adminRole->givePermissionTo(Permission::all());
        $authorRole->givePermissionTo(['create post', 'edit post']);
        $viewerRole->givePermissionTo('view post');
    }
}
